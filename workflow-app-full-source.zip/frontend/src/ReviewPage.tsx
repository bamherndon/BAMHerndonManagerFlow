import React, { useEffect, useState } from "react";

export default function ReviewPage() {
  const [items, setItems] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    fetch("/api/import-items").then((r) => r.json()).then(setItems);
  }, []);

  if (!items.length) return <div className="p-4">Loading...</div>;

  const { po_number, item_description, po_line_qty, po_line_unit_cost, item_current_price, item_bricklink_id } = items[currentIndex];

  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold mb-4">Reviewing Item {currentIndex+1} of {items.length}</h2>
      <div className="border p-4 rounded bg-white shadow">
        <p><strong>PO Number:</strong> {po_number}</p>
        <p><strong>Item Description:</strong> {item_description}</p>
        <p><strong>Quantity:</strong> {po_line_qty}</p>
        <p><strong>Unit Cost:</strong> ${po_line_unit_cost}</p>
        <p><strong>Current Price:</strong> ${item_current_price}</p>
        <p><strong>Bricklink ID:</strong> {item_bricklink_id}</p>
      </div>
      <div className="flex justify-between mt-4">
        <button onClick={() => setCurrentIndex(i => Math.max(0, i-1))} disabled={currentIndex===0} className="px-4 py-2 bg-gray-300 rounded disabled:opacity-50">Previous</button>
        <button onClick={() => setCurrentIndex(i => Math.min(items.length-1, i+1))} disabled={currentIndex===items.length-1} className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50">Next</button>
      </div>
    </div>
);